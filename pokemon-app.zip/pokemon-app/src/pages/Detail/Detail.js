import React from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

class Detail extends  React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            ability: [],
            weight: PropTypes.number,
            height: PropTypes.number,
        };
    }
    componentDidMount() {
        const ID = this.props.Data+1;
        axios.get(`https://pokeapi.co/api/v2/pokemon/${ID}`).then((response) => {
          //console.log(response.data);

            const loadingTimer = setTimeout(() => {
                clearTimeout(loadingTimer);
                this.setState({
                    loading: false,
                    height: response.data.height,
                    weight: response.data.weight,
                    ability:response.data.abilities,
                });
            }, 1500);
        }).catch(() => {
            const loadingTimer = setTimeout(() => {
                clearTimeout(loadingTimer);
                this.setState({
                    loading: false,
                });
            }, 1500);
        });
    }
render(){
  const { loading, height, weight, ability } = this.state;
  //console.log(ability);
    return (
        <div>
            <p>Details:</p>
            <Card>
            <CardContent>
            <p>height: {height}</p>
            </CardContent>
            </Card>
            <Card>
            <CardContent>
            <p>weight: {weight}</p>
            </CardContent>
            </Card>
            <p>Ability:</p>
            {ability.map((abilities,index) => {
                return (
                  <Card>
                  <CardContent>
                  <div key={index}>
                  <p>{index+1}: {abilities.ability.name}</p>
                  </div>
                  </CardContent>
                  </Card>
                );
              })}
        </div>
    );
  }
}

export default Detail;

import React, { Component } from 'react';
import axios from 'axios';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import styles from './Feed.module.css';
import Grid from '@material-ui/core/Grid';
import Loading from '../../components/Loading/Loading';
import Detail from '../Detail/Detail';

class Feed extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            pokemons: [],
            error: null,
        };
    }

    componentDidMount() {
        axios.get('https://pokeapi.co/api/v2/pokemon?limit=151').then((response) => {
          //console.log(response.data);
            const loadingTimer = setTimeout(() => {
                clearTimeout(loadingTimer);
                this.setState({
                    loading: false,
                    pokemons: response.data.results,
                });
            }, 1500);
        }).catch(() => {
            const loadingTimer = setTimeout(() => {
                clearTimeout(loadingTimer);
                this.setState({
                    loading: false,
                    error: true,
                });
            }, 1500);
        });
    }

    render() {
        const { loading, pokemons, error } = this.state;
        return (
            <div className={styles.feed}>
                <h2>Pokedex</h2>
                {!loading && error && (
                    <p>There was an error retrieving your information.</p>
                )}
                {loading ? (
                    <Loading />
                ) : (
                    <React.Fragment>
                        {pokemons.map((pokemon, index) => {
                            return (
                                <div key={pokemon.name} className={styles.pokemon}>
                                <Grid container spacing={50}>
                                <Grid item xs={36} sm={36}>
                                <Card>
                                <CardContent>
                                <h3>{pokemon.name}</h3>
                                <p>ID: {index+1}</p>
                                <img src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${index+1}.png`} alt={ pokemon.name }/>
                                </CardContent>
                                <CardActions>
                                < Detail Data = {index} />
                                </CardActions>
                                </Card>
                                </Grid>
                                </Grid>
                                </div>
                              );
                            })}
                            </React.Fragment>
                          )}
                          </div>
                        );
                      }
                    }
export default Feed;

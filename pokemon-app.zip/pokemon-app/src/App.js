import React, { Component } from 'react';
import { NavLink, Switch, Route } from 'react-router-dom';
import styles from './App.module.css';
import Feed from './pages/Feed/Feed';

class App extends Component {
  render() {
    return (
      <div className={styles.app}>
        <header className={styles.header}>
          <h1>My Pokemon API</h1>
          <nav>
            <ul>
              <li>
                <NavLink to="/">Pokedex</NavLink>
              </li>
            </ul>
          </nav>
        </header>
        <main>
          <Switch>
            <Route exact path="/" component={Feed} />
          </Switch>
        </main>
      </div>
    );
  }
}

export default App;
